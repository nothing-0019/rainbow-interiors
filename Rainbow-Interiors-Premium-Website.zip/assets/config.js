/* Business details transcribed from the supplied Rainbow Interiors listing screenshot. */
window.RAINBOW_CONFIG = {
  name: "Rainbow Interiors",
  category: "Interior Designer, Residential Interiors and Modular Kitchen Design",
  phone: "+919398359117",
  address: "127, Adjeetpura Nagar, Adarsh Nagar, Gurumurthy Nagar, Balanagar, Hyderabad, Telangana 500037, India",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=127%2C+Adjeetpura+Nagar%2C+Adarsh+Nagar%2C+Gurumurthy+Nagar%2C+Balanagar%2C+Hyderabad%2C+Telangana+500037",
  googleRating: "4.8",
  googleReviewCount: "22",
  whatsapp: "+919398359117",
  email: "",
  instagramProfile: ""
};
