/* Rainbow Interiors — interaction layer */
(() => {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const body = document.body;
  const progress = document.createElement('div');
  progress.id = 'vj-progress';
  document.body.appendChild(progress);

  const cursor = document.createElement('div');
  cursor.id = 'vj-cursor';
  cursor.setAttribute('aria-hidden','true');
  document.body.appendChild(cursor);
  let pointerX = innerWidth/2, pointerY = innerHeight/2;
  document.addEventListener('pointermove', e => {
    pointerX = e.clientX; pointerY = e.clientY;
    cursor.style.left = pointerX + 'px'; cursor.style.top = pointerY + 'px';
  }, {passive:true});
  document.querySelectorAll('a,button,.project-card,.service-card,.concept-card').forEach(el => {
    el.addEventListener('pointerenter', () => cursor.classList.add('is-hover'));
    el.addEventListener('pointerleave', () => cursor.classList.remove('is-hover'));
  });

  const updateProgress = () => {
    const max = document.documentElement.scrollHeight - innerHeight;
    progress.style.width = (max > 0 ? scrollY/max*100 : 0) + '%';
  };
  addEventListener('scroll', updateProgress, {passive:true}); updateProgress();

  if (!reduce && 'IntersectionObserver' in window) {
    const candidates = document.querySelectorAll('main section:not(.hero) h2, main section:not(.hero) .section-heading, .project-card, .service-card, .concept-card, .review-card, .brand-proof-inner > *');
    candidates.forEach((el,i) => {
      el.classList.add('motion-reveal');
      if (i % 4) el.dataset.delay = String(i % 4);
    });
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
    }), {threshold:.12, rootMargin:'0px 0px -35px 0px'});
    candidates.forEach(el => observer.observe(el));
  }

  // A low-key perspective response gives project tiles physical depth.
  if (!reduce && matchMedia('(pointer:fine)').matches) {
    document.querySelectorAll('.project-card, .concept-card, .service-card').forEach(card => {
      card.addEventListener('pointermove', e => {
        const r = card.getBoundingClientRect();
        const x = (e.clientX-r.left)/r.width-.5;
        const y = (e.clientY-r.top)/r.height-.5;
        card.style.transform = `perspective(900px) rotateY(${x*3}deg) rotateX(${-y*3}deg) translateY(-3px)`;
      });
      card.addEventListener('pointerleave', () => { card.style.transform = ''; });
    });
  }

  // Add an editorial moving type strip beneath the homepage hero.
  if (body.classList.contains('page-home')) {
    const hero = document.querySelector('.hero');
    if (hero && !document.getElementById('vj-marquee')) {
      const strip = document.createElement('div');
      strip.id = 'vj-marquee';
      strip.setAttribute('aria-label','Design and build, from first sketch to final detail');
      const phrase = '<span>Spaces with a point of view <b>✳</b></span><span>Design, detail, delivery <b>✳</b></span><span>Made for the way you live <b>✳</b></span><span>Hyderabad · India <b>✳</b></span>';
      strip.innerHTML = '<div class="marquee-track">' + phrase + phrase + '</div>';
      hero.insertAdjacentElement('afterend', strip);
    }
  }

  // Pause the existing hero carousel while the visitor interacts with its controls.
  const hero = document.querySelector('.hero-immersive');
  if (hero) {
    hero.addEventListener('mouseenter', () => hero.dataset.hovered = 'true');
    hero.addEventListener('mouseleave', () => delete hero.dataset.hovered);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) hero.dataset.paused = 'true'; else delete hero.dataset.paused;
    });
  }
})();
