(() => {
  const planner = document.querySelector('#budgetPlanner');
  if (!planner) return;
  const budgetInput = document.querySelector('#plannerBudget');
  const areaInput = document.querySelector('#plannerArea');
  const spaces = [...document.querySelectorAll('[data-space]')];
  const total = document.querySelector('#calcTotal');
  const perSqFt = document.querySelector('#calcPerSqft');
  const bar = document.querySelector('#allocationBar');
  const list = document.querySelector('#allocationList');
  const message = document.querySelector('#calcMessage');
  const planLink = document.querySelector('#usePlan');
  const helper = document.querySelector('#budgetHelper');
  const helperDefault = helper ? helper.textContent : '';
  const palette = ['#cba77c', '#99a18a', '#718171', '#c78970', '#ded0ad'];
  const MIN = 5000;
  const money = amount => '₹' + Math.round(amount).toLocaleString('en-IN');
  const formatArea = amount => Math.round(amount).toLocaleString('en-IN');
  const urlBudget = new URLSearchParams(location.search).get('budget');
  if (urlBudget && Number(urlBudget) >= MIN) budgetInput.value = Math.floor(Number(urlBudget));

  // Whole-number percentages that always add up to exactly 100 (largest remainder).
  function wholePercents(weights) {
    const sum = weights.reduce((a, b) => a + b, 0);
    const raw = weights.map(w => w / sum * 100);
    const floor = raw.map(Math.floor);
    let left = 100 - floor.reduce((a, b) => a + b, 0);
    raw.map((r, i) => [r - floor[i], i]).sort((a, b) => b[0] - a[0]).forEach(([, i]) => { if (left-- > 0) floor[i]++; });
    return floor;
  }
  function empty(text, invalid) {
    bar.replaceChildren(); list.replaceChildren();
    const note = document.createElement('p');
    note.className = 'calc-empty'; note.textContent = text; list.appendChild(note);
    if (planLink) { planLink.setAttribute('aria-disabled', 'true'); planLink.removeAttribute('href'); }
    try { sessionStorage.removeItem('rainbowBudgetPlan'); } catch (_) {}
    message.textContent = '';
    budgetInput.setAttribute('aria-invalid', String(!!invalid));
  }
  function calculate() {
    const amount = Math.max(0, Number(budgetInput.value) || 0);
    const area = Math.max(0, Number(areaInput.value) || 0);
    const valid = amount >= MIN;
    const prevTotal = total.textContent;
    total.textContent = money(amount);
    if (prevTotal !== total.textContent) { total.classList.remove('tick'); void total.offsetWidth; total.classList.add('tick'); }
    if (helper) {
      helper.textContent = valid ? helperDefault : 'Enter a total budget of at least ₹5,000 to see your split.';
      helper.classList.toggle('error', !valid);
    }
    perSqFt.textContent = area && valid ? money(amount / area) + ' per sq. ft. across ' + formatArea(area) + ' sq. ft.' : 'Add your home area for a budget-per-square-foot reference.';
    if (!valid) return empty('Your split appears here once you enter a budget.', true);
    budgetInput.setAttribute('aria-invalid', 'false');
    const selected = spaces.filter(input => input.checked).map((input, index) => ({
      name: input.value,
      weight: Number(input.dataset.weight) * Number(input.closest('.calc-space').querySelector('[data-priority]').value),
      color: palette[index % palette.length]
    }));
    if (!selected.length) return empty('Choose at least one space to see a split.', false);
    bar.replaceChildren(); list.replaceChildren();
    const percents = wholePercents(selected.map(s => s.weight));
    const weightTotal = selected.reduce((sum, item) => sum + item.weight, 0);
    let assigned = 0;
    const details = selected.map((item, index) => {
      const share = index === selected.length - 1 ? amount - assigned : Math.round(amount * item.weight / weightTotal);
      assigned += share;
      const percent = percents[index];
      const segment = document.createElement('span');
      segment.style.width = (item.weight / weightTotal * 100) + '%';
      segment.style.backgroundColor = item.color;
      segment.title = item.name + ' · ' + percent + '%';
      bar.appendChild(segment);
      const row = document.createElement('div');
      row.className = 'allocation-row';
      const name = document.createElement('strong'); name.textContent = item.name;
      const pct = document.createElement('small'); pct.textContent = percent + '% of your budget';
      const value = document.createElement('span'); value.className = 'amount'; value.textContent = money(share);
      row.append(name, pct, value);
      list.appendChild(row);
      return item.name + ': ' + money(share) + ' (' + percent + '%)';
    });
    const summary = [
      'Rainbow Interiors — Budget planning split',
      'Total budget: ' + money(amount),
      area ? 'Home area: ' + formatArea(area) + ' sq. ft.' : '',
      ...details,
      'Indicative planning allocation only; not a cost estimate or quote.'
    ].filter(Boolean).join('\n');
    try { sessionStorage.setItem('rainbowBudgetPlan', JSON.stringify({ amount, area, summary })); } catch (_) {}
    if (planLink) { planLink.removeAttribute('aria-disabled'); planLink.href = 'enquiry.html?from=planner'; }
    message.textContent = 'Split updated.';
  }
  budgetInput.addEventListener('input', calculate);
  areaInput.addEventListener('input', calculate);
  spaces.forEach(input => {
    input.addEventListener('change', calculate);
    input.closest('.calc-space').querySelector('[data-priority]').addEventListener('change', calculate);
  });
  planLink && planLink.addEventListener('click', e => { if (planLink.getAttribute('aria-disabled') === 'true') e.preventDefault(); });
  const copy = document.querySelector('#copyPlan');
  copy.addEventListener('click', async () => {
    let summary = '';
    try { const saved = sessionStorage.getItem('rainbowBudgetPlan'); summary = saved ? JSON.parse(saved).summary : ''; } catch (_) {}
    if (!summary) { message.textContent = 'Enter a budget and choose a space first, then copy.'; return; }
    try {
      await navigator.clipboard.writeText(summary);
      message.textContent = 'Breakdown copied.';
      const label = copy.textContent; copy.textContent = 'Copied ✓'; copy.classList.add('copied');
      setTimeout(() => { copy.textContent = label; copy.classList.remove('copied'); }, 1800);
    } catch (_) {
      const range = document.createRange(); range.selectNodeContents(list);
      const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
      message.textContent = 'Copy isn’t available here. The breakdown is selected, so press Ctrl/Cmd+C.';
    }
  });
  const reset = document.querySelector('#resetPlan');
  reset && reset.addEventListener('click', () => {
    budgetInput.value = budgetInput.defaultValue; areaInput.value = '';
    spaces.forEach(input => { input.checked = input.defaultChecked; input.closest('.calc-space').querySelector('[data-priority]').selectedIndex = [...input.closest('.calc-space').querySelector('[data-priority]').options].findIndex(o => o.defaultSelected) ; });
    calculate(); message.textContent = 'Planner reset to its starting values.'; budgetInput.focus();
  });
  calculate();
})();
