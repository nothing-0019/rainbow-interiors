(() => {
  if ((navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2) || (navigator.connection && navigator.connection.saveData)) document.documentElement.classList.add('lite');
  const config = window.RAINBOW_CONFIG || {};
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav-links');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      toggle.textContent = open ? 'Close' : 'Menu';
    });
    const closeMenu = () => { nav.classList.remove('open'); toggle.setAttribute('aria-expanded', 'false'); toggle.setAttribute('aria-label', 'Open navigation'); toggle.textContent = 'Menu'; };
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && nav.classList.contains('open')) { closeMenu(); toggle.focus(); } });
    document.addEventListener('click', e => { if (nav.classList.contains('open') && !e.target.closest('.nav-wrap')) closeMenu(); });
    window.matchMedia('(min-width:981px)').addEventListener('change', closeMenu);
    nav.addEventListener('click', event => {
      if (event.target.closest('a')) {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.textContent = 'Menu';
      }
    });
  }
  const mobileQuickbar = document.createElement('div');
  mobileQuickbar.className = 'mobile-quickbar';
  mobileQuickbar.innerHTML = '<a href="calculator.html">Budget Calculator</a><a href="enquiry.html">Book a consultation</a>';
  document.body.appendChild(mobileQuickbar);
  const quickBudget = document.querySelector('#quickBudget');
  const quickPlannerLink = document.querySelector('#quickPlannerLink');
  if (quickBudget && quickPlannerLink) {
    const updatePlannerLink = () => {
      const amount = Math.max(0, Math.floor(Number(quickBudget.value) || 0));
      quickPlannerLink.href = 'calculator.html' + (amount ? '?budget=' + amount : '');
    };
    quickBudget.addEventListener('input', updatePlannerLink);
    updatePlannerLink();
  }

  const current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(link => {
    if (link.getAttribute('href') === current) link.setAttribute('aria-current', 'page');
  });
  document.querySelectorAll('.year').forEach(el => el.textContent = new Date().getFullYear());
  document.querySelectorAll('.instagram-link').forEach(link => {
    if (config.instagramProfile) {
      link.href = config.instagramProfile;
      link.style.display = 'inline-flex';
      link.target = '_blank';
      link.rel = 'noopener';
    }
  });

  const swatchDetail = document.querySelector('#swatchDetail');
  document.querySelectorAll('.swatch').forEach(button => {
    button.addEventListener('click', () => {
      if (swatchDetail) swatchDetail.textContent = button.dataset.name + ' · ' + button.dataset.hex + ' — an approximate on-screen reference, not a guaranteed paint or material match.';
    });
  });
  const paletteButtons = document.querySelectorAll('.palette-card');
  const preview = document.querySelector('#palettePreview');
  const selectedLabel = document.querySelector('#selectedPalette');
  function choosePalette(card, describe = true) {
    paletteButtons.forEach(item => item.setAttribute('aria-pressed', String(item === card)));
    if (!preview) return;
    preview.style.setProperty('--p1', card.dataset.p1);
    preview.style.setProperty('--p2', card.dataset.p2);
    preview.style.setProperty('--p3', card.dataset.p3);
    preview.style.setProperty('--p4', card.dataset.p4);
    if (selectedLabel) selectedLabel.textContent = card.dataset.palette;
    if (describe && swatchDetail) swatchDetail.textContent = card.dataset.palette + ': ' + [...card.querySelectorAll('.swatch')].map(sw => sw.dataset.name + ' ' + sw.dataset.hex).join(' · ') + ' — approximate on-screen references, not guaranteed paint or material matches.';
    try { sessionStorage.setItem('rainbowPalette', card.dataset.palette); } catch (_) {}
  }
  paletteButtons.forEach(card => card.addEventListener('click', e => choosePalette(card, !e.target.closest('.swatch'))));
  if (paletteButtons.length) {
    let saved = '';
    try { saved = sessionStorage.getItem('rainbowPalette') || ''; } catch (_) {}
    choosePalette([...paletteButtons].find(card => card.dataset.palette === saved) || paletteButtons[0]);
  }
  const paletteInput = document.querySelector('#colourPreference');
  if (paletteInput) {
    try { paletteInput.value = sessionStorage.getItem('rainbowPalette') || ''; } catch (_) {}
  }
  const spaceSelect = document.querySelector('#space');
  if (spaceSelect) {
    const requestedService = new URLSearchParams(location.search).get('service');
    if (requestedService && [...spaceSelect.options].some(option => option.value === requestedService || option.text === requestedService)) {
      spaceSelect.value = requestedService;
    }
  }

  const filters = document.querySelectorAll('.filter-chip');
  const projects = document.querySelectorAll('.project-card[data-category]');
  filters.forEach(filter => filter.addEventListener('click', () => {
    filters.forEach(item => item.setAttribute('aria-pressed', String(item === filter)));
    const value = filter.dataset.filter;
    projects.forEach(project => project.hidden = value !== 'all' && project.dataset.category !== value);
  }));

  const form = document.querySelector('#budgetEnquiry');
  if (form) {
    const catalogueChoice = new URLSearchParams(location.search).get('catalogue');
    if (catalogueChoice) {
      const details = form.querySelector('[name="details"]');
      const status = document.querySelector('#formStatus');
      if (details) details.value = 'Colour catalogue selection: ' + catalogueChoice;
      if (status) status.textContent = 'Your selected PVC sheet has been added. Add your contact and project details to continue.';
    }
  }
  if (form && new URLSearchParams(location.search).get('from') === 'planner') {
    try {
      const plan = JSON.parse(sessionStorage.getItem('rainbowBudgetPlan') || 'null');
      if (plan) {
        const budget = form.querySelector('[name="budget"]');
        const details = form.querySelector('[name="details"]');
        const status = document.querySelector('#formStatus');
        if (budget && plan.amount) budget.value = plan.amount;
        if (details && plan.summary) details.value = plan.summary;
        if (status) status.textContent = 'Your budget split has been added. Add your contact and project details to continue.';
      }
    } catch (_) {}
  }
  if (form) form.addEventListener('submit', event => {
    event.preventDefault();
    if (!validateForm(form)) return;
    if (form.dataset.busy) return;
    const submitBtn = form.querySelector('[type=submit]');
    form.dataset.busy = '1'; if (submitBtn) submitBtn.disabled = true;
    setTimeout(() => { delete form.dataset.busy; if (submitBtn) submitBtn.disabled = false; }, 3000);
    const data = new FormData(form);
    const lines = [
      'Rainbow Interiors — Design Enquiry',
      'Name: ' + data.get('name'),
      'Phone: ' + data.get('phone'),
      'Email: ' + (data.get('email') || 'Not provided'),
      'Space: ' + data.get('space'),
      'Approximate budget: ' + (data.get('budget') ? '₹' + Number(data.get('budget')).toLocaleString('en-IN') : 'Flexible'),
      'Preferred palette: ' + (data.get('palette') || 'Not selected'),
      'Start timeline: ' + data.get('timeline'),
      'Notes: ' + (data.get('details') || 'None')
    ];
    const message = lines.join('\n');
    const status = document.querySelector('#formStatus');
    if (config.whatsapp) {
      const phone = String(config.whatsapp).replace(/\D/g, '');
      if (phone.length >= 10) {
        window.open('https://wa.me/' + phone + '?text=' + encodeURIComponent(message), '_blank', 'noopener');
        status.textContent = 'Your enquiry is ready in WhatsApp. Review the message and press Send.';
        return;
      }
    }
    if (config.email) {
      location.href = 'mailto:' + encodeURIComponent(config.email) + '?subject=' + encodeURIComponent('Rainbow Interiors design enquiry') + '&body=' + encodeURIComponent(message);
      status.textContent = 'Your email app is opening with the enquiry details.';
      return;
    }
    status.textContent = 'The enquiry is ready, but the studio contact is not connected yet. Nothing has been sent. Copy the text below and share it with the studio yourself.';
    const previewMessage = document.querySelector('#messagePreview');
    if (previewMessage) {
      previewMessage.textContent = message;
      previewMessage.hidden = false;
    }
    const copyButton = document.querySelector('#copyMessage');
    if (copyButton) copyButton.hidden = false;
  });
  const copyButton = document.querySelector('#copyMessage');
  if (copyButton) copyButton.addEventListener('click', async () => {
    const text = document.querySelector('#messagePreview')?.textContent || '';
    try {
      await navigator.clipboard.writeText(text);
      const status = document.querySelector('#formStatus');
      if (status) status.textContent = 'Enquiry copied. Share it with the studio through your preferred contact method.'; const l = copyButton.textContent; copyButton.textContent = 'Copied ✓'; setTimeout(() => copyButton.textContent = l, 1800);
    } catch (_) {
      const preview = document.querySelector('#messagePreview');
      if (preview) {
        const range = document.createRange();
        range.selectNodeContents(preview);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
      }
    }
  });

  // Sticky header state
  const header = document.querySelector('.site-header');
  if (header) {
    const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 24);
    onScroll(); window.addEventListener('scroll', onScroll, { passive: true });
  }
  // Scroll reveals (fall back to visible if IntersectionObserver is missing)
  const reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const io = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('in'); io.unobserve(entry.target); } }), { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    reveals.forEach(el => io.observe(el));
  } else reveals.forEach(el => el.classList.add('in'));
  // Confirmed contact details only (from assets/config.js)
  const wa = String(config.whatsapp || '').replace(/\D/g, '');
  document.querySelectorAll('.contact-wa').forEach(a => { if (wa.length >= 10) { a.href = 'https://wa.me/' + wa; a.hidden = false; a.target = '_blank'; a.rel = 'noopener'; } });
  document.querySelectorAll('.contact-mail').forEach(a => { if (config.email) { a.href = 'mailto:' + config.email; a.hidden = false; } });
  // Enquiry validation with clear inline messages
  function validateForm(form) {
    let first = null;
    const rules = [
      ['name', v => v.trim().length > 1, 'Enter your name.'],
      ['phone', v => /^[0-9+() -]{8,18}$/.test(v.trim()), 'Enter a phone number with 8–18 digits, for example 98765 43210.'],
      ['email', v => !v.trim() || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()), 'Enter a valid email address, or leave it blank.'],
      ['space', v => !!v, 'Choose what you are planning.']
    ];
    rules.forEach(([name, ok, msg]) => {
      const field = form.elements[name]; if (!field) return;
      const wrap = field.closest('.field');
      let err = wrap.querySelector('.field-error');
      if (!err) { err = document.createElement('span'); err.className = 'field-error'; err.id = name + 'Error'; err.setAttribute('role', 'alert'); wrap.appendChild(err); }
      const good = ok(field.value);
      field.setAttribute('aria-invalid', String(!good));
      if (!good) field.setAttribute('aria-describedby', err.id); else field.removeAttribute('aria-describedby');
      err.textContent = good ? '' : msg;
      if (!good && !first) first = field;
    });
    if (first) { first.focus(); const st = document.querySelector('#formStatus'); if (st) st.textContent = 'Please fix the highlighted fields to continue.'; }
    return !first;
  }
  const _form = document.querySelector('#budgetEnquiry');
  if (_form) _form.setAttribute('novalidate', '');

  // Colour Studio: copy and reset
  const copyPalette = document.querySelector('#copyPalette'), resetPalette = document.querySelector('#resetPalette'), palStatus = document.querySelector('#paletteStatus');
  if (copyPalette) copyPalette.addEventListener('click', async () => {
    const card = document.querySelector('.palette-card[aria-pressed=true]'); if (!card) return;
    const text = card.dataset.palette + ' (approximate on-screen colours)\n' + [...card.querySelectorAll('.swatch')].map(sw => sw.dataset.name + ' ' + sw.dataset.hex).join('\n');
    try { await navigator.clipboard.writeText(text); palStatus.textContent = 'Palette values copied.'; const l = copyPalette.textContent; copyPalette.textContent = 'Copied ✓'; setTimeout(() => copyPalette.textContent = l, 1800); }
    catch (_) { palStatus.textContent = 'Copy isn’t available here. Palette: ' + text.replace(/\n/g, ', '); }
  });
  if (resetPalette) resetPalette.addEventListener('click', () => {
    try { sessionStorage.removeItem('rainbowPalette'); } catch (_) {}
    choosePalette(paletteButtons[0]);
    try { sessionStorage.removeItem('rainbowPalette'); } catch (_) {}
    palStatus.textContent = 'Palette reset. Nothing is carried into your enquiry until you choose one.';
  });

  // Concept brief (rule-based starting point; nothing is sent anywhere)
  const briefRoom = document.querySelector('#briefRoom');
  if (briefRoom) {
    const PAL = {"Soft Neutrals": ["#f1ece2", "#cabaa5", "#a6a08f", "#806e5b"], "Earth & Clay": ["#eee2d3", "#d1a589", "#aa694f", "#705546"], "Garden Greens": ["#e4eadf", "#a7be9c", "#5f8b67", "#355b49"], "Blue Hour": ["#e6ebf4", "#a6bbd1", "#5f7fa9", "#394d75"], "Soft Colour": ["#f1dce5", "#dda0b2", "#ce7289", "#795778"], "Sunlit Accent": ["#f7edcb", "#f0cd55", "#e1a323", "#aa6851"]};
    const ROOM = { 'Living & dining': ['Living & dining', 'seating, lighting and a calm backdrop for everyday living'], 'Kitchen': ['Modular kitchen design', 'layout, storage and surfaces that suit daily use'], 'Bedroom': ['Bedrooms and wardrobes', 'a restful palette, storage and layered lighting'], 'Whole home': ['Residential interiors', 'a consistent look carried from room to room'] };
    const DIR = { 'Warm minimal': ['Soft Neutrals', 'quiet neutrals, natural textures and a few well-chosen pieces'], 'Earthy & natural': ['Earth & Clay', 'clay tones, warm wood and tactile finishes'], 'Garden calm': ['Garden Greens', 'soft greens, light wood and plenty of daylight'], 'Soft colour': ['Soft Colour', 'gentle colour accents against calm walls'] };
    const SCOPE = { 'Refresh the look': 'update colour, lighting and key finishes', 'Redesign the room': 'rethink layout, storage and furniture alongside finishes', 'Full interior': 'plan the space end to end, from layout to final details' };
    const dirSel = document.querySelector('#briefDirection'), scopeSel = document.querySelector('#briefScope');
    const title = document.querySelector('#briefTitle'), text = document.querySelector('#briefText'), sw = document.querySelector('#briefSwatches'), bStatus = document.querySelector('#briefStatus');
    let brief = '';
    function renderBrief() {
      const room = briefRoom.value, dir = dirSel.value, scope = scopeSel.value, palette = DIR[dir][0];
      title.textContent = dir + ' ' + room.toLowerCase();
      text.textContent = 'A ' + room.toLowerCase() + ' built around ' + ROOM[room][1] + ', in a direction of ' + DIR[dir][1] + '. The aim: ' + SCOPE[scope] + '.';
      sw.replaceChildren(...PAL[palette].map(hex => { const i = document.createElement('i'); i.style.background = hex; return i; }));
      brief = ['Room concept brief', 'Room: ' + room, 'Direction: ' + dir + ' (palette: ' + palette + ')', 'Scope: ' + scope, text.textContent, 'A simple starting brief for discussion; not a design or a quotation.'].join('\n');
      bStatus.textContent = '';
    }
    [briefRoom, dirSel, scopeSel].forEach(el => el.addEventListener('change', renderBrief));
    document.querySelector('#briefUse').addEventListener('click', () => {
      try { sessionStorage.setItem('rainbowBrief', JSON.stringify({ text: brief, space: ROOM[briefRoom.value][0] })); sessionStorage.setItem('rainbowPalette', DIR[dirSel.value][0]); } catch (_) {}
    });
    document.querySelector('#briefCopy').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(brief); bStatus.textContent = 'Brief copied.'; }
      catch (_) { bStatus.textContent = 'Copy isn’t available here. Select the brief text above to copy it.'; }
    });
    renderBrief();
  }
  // Enquiry prefill from the concept brief
  const _bf = document.querySelector('#budgetEnquiry');
  if (_bf && new URLSearchParams(location.search).get('from') === 'brief') {
    try {
      const b = JSON.parse(sessionStorage.getItem('rainbowBrief') || 'null');
      if (b) {
        const d = _bf.querySelector('[name="details"]'), sp = _bf.querySelector('[name="space"]'), st = document.querySelector('#formStatus');
        if (d) d.value = b.text;
        if (sp && [...sp.options].some(o => o.value === b.space)) sp.value = b.space;
        if (st) st.textContent = 'Your concept brief has been added. Add your contact details to continue.';
      }
    } catch (_) {}
  }
})();
