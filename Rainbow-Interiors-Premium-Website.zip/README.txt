RAINBOW INTERIORS INTERIORS — WEBSITE PROJECT

A responsive multi-page static website for Rainbow Interiors, Balanagar, Hyderabad.

OPEN LOCALLY
Open index.html in a modern browser, or upload the complete folder contents to a static web host.

PAGES
- index.html — Home
- about.html — About Us
- services.html — Services
- projects.html — Our Designs (illustrative concept imagery)
- reviews.html — Design inspiration and business rating context
- enquiry.html — Enquiry form and contact details
- colours.html — Colour Studio and supplied PVC finish catalogue
- calculator.html — Indicative budget planner

BUSINESS DETAILS
Rainbow Interiors
127, Adjeetpura Nagar, Adarsh Nagar, Gurumurthy Nagar, Balanagar, Hyderabad, Telangana 500037, India
Phone / WhatsApp: +91 93983 59117
Availability: Open 24 Hours
Displayed business rating: 4.8 stars (no review count shown)

FUNCTIONALITY
- Responsive navigation and mobile quick actions
- WhatsApp-based enquiry form with browser-side validation and message preview
- Direct telephone and WhatsApp links; Google Maps directions and embedded map
- Concept gallery, service pages, palette studio, material catalogue and budget planner
- Reduced-motion support and keyboard focus styles

IMPORTANT CONTENT NOTE
The supplied interior images are illustrative design concepts, not verified completed client projects. The website does not fabricate testimonials, review counts, awards, certifications, email addresses or social accounts. Confirm service scope, business details and all imagery permissions before publishing.

TECHNICAL
This is a static HTML/CSS/JavaScript project. The enquiry form prepares a WhatsApp message for the visitor to review and send; it does not silently submit data to a backend. Google Fonts and the embedded Google Map require an internet connection.
